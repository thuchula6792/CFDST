clear all
close all
clc

% Plot the sensitivity of all input variables based on the trained ANN.
% In the sensitivity analysis, each parameter is varied from its lowest
% value to its highest value, while other parameters are remained constant
% at their mean values.
% Results similar to those plotted in Figure 10 of the paper "Application
% of ANN to the design of CFST columns" (Mohammadreza Zarringol, Huu-Tai
% Thai, Son Thai, Vipulkumar Patel, 2020) are calculated and plotted. Url:
% % https://doi.org/10.1016/j.istruc.2020.10.048
% The same type of sensitivity analysis is performed in the paper
% "Application of machine learning models for designing CFCFST columns"
% (Mohammadreza Zarringol Huu-Tai Thai, M.Z.Naser, 2021) url:
% https://doi.org/10.1016/j.jcsr.2021.106856



% M=xlsread('Supplementary-data.xlsx','Comparison','A2:S126');
l={'L(mm)','Do(mm)','to(mm)','Di(mm)','ti(mm)','fyo(MPa)','fyi(MPa)','fc''(MPa)','Pu(kN)'};
% save xlsVar.mat
% Input and output data for training the neural network
load xlsVar.mat M
xtrn=zscore(M(:,1:8),0,1)';
Cxtrn=mean(M(:,1:8),1)';
Sxtrn=std(M(:,1:8),0,1)';
ttrn=zscore(M(:,9),0,1)';
Cttrn=mean(M(:,9),1)';
Sttrn=std(M(:,9),0,1)';

% Results for GA-ANN
load optNet_ga1.mat net

Pu=zeros(size(M,1),1);
for i=1:size(M,1)
    L=M(i,1);
    Do=M(i,2);
    to=M(i,3);
    Di=M(i,4);
    ti=M(i,5);
    fyo=M(i,6);
    fyi=M(i,7);
    fc=M(i,8);
    Pu(i)=prediction_ANN(L,Do,to,Di,ti,fyo,fyi,fc,M,net);
end


comparisonFig(M(:,9),Pu,'GA-ANN-1H');

close all

