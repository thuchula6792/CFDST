function Pu=prediction_ANN(L,Do,to,Di,ti,fyo,fyi,fc,M,net)


% Calculations
Cxtrn=mean(M(:,1:8),1)';
Sxtrn=std(M(:,1:8),0,1)';
Cttrn=mean(M(:,9),1)';
Sttrn=std(M(:,9),0,1)';

x=([L;Do;to;Di;ti;fyo;fyi;fc]-Cxtrn)./Sxtrn;
y = net(x);

% Result
Pu=y*Sttrn+Cttrn;

end

