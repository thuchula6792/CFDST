function comparisonFig(P_actual,X,titl)
figure()
k=max([P_actual;X]);
k=1000*ceil(k/1000);
plot([0,k],[0,k],'LineStyle','--','Color','red', 'LineWidth', 1);
hold on
scatter(X,P_actual,'Marker','o','CData',[0,0,1], 'LineWidth', 1)

coefficients = polyfit(P_actual, X, 1);
% Create a new x axis with exactly 1000 points (or whatever you want).
xFit = linspace(0, k, 10);
% Get the estimated yFit value for each of those 1000 new x locations.
yFit = polyval(coefficients , xFit);
% Plot everything
plot(yFit, xFit, 'k-', 'LineWidth', 1); % Plot fitted line.
grid on;
xlabel('Predicted P_u (kN)')
ylabel('Actual P_u (kN)')
Cyt=corrcoef(X,P_actual);
R2=Cyt(2,1);
legend({'Diagonal',['Data, R^2=',num2str(R2^2)],'Linear fit'},'Location','NorthWest');
title(titl)
hold off
xlim([0,k])
ylim([0,k])

savefig([titl,'.fig'])
saveas(gcf,titl,'png')
saveas(gcf,titl,'meta')
end

